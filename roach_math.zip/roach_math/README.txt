Roach Deck Calculator - Desktop App

How to run:
1. Unzip this folder.
2. Double-click "roach_gui.exe" to launch the app.
3. Enter the values for:
   - pp (Power Points)
   - zero_costs
   - cairn
4. Click the buttons to see the damage and combos.

Requirements:
- No installation needed, this is a standalone executable.
- Tested on Windows.
